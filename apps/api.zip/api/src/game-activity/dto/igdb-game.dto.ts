export interface IgdbGameDto {
  id: number;
  name: string;
  cover?: {
    image_id: string;
  };
}
