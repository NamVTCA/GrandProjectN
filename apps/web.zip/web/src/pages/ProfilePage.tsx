import React, { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import api from '../services/api';
import ProfileHeader from '../features/profile/components/ProfileHeader';
import UserPostList from '../features/profile/components/UserPostList';
import type { UserProfile } from '../features/profile/types/UserProfile';
import { useAuth } from '../features/auth/AuthContext';
import './ProfilePage.scss';

const ProfilePage: React.FC = () => {
  const { username } = useParams<{ username: string }>();
  const { user: currentUser } = useAuth();

  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = useCallback(async () => {
    if (!username) return;
    setLoading(true);
    setError(null);
    try {
      const { data } = await api.get<UserProfile>(`/users/${username}`);
      setUserProfile(data);
      setIsFollowing(!!currentUser && data.followers.includes(currentUser._id));
    } catch (err) {
      console.error(err);
      setError('Không tìm thấy người dùng hoặc đã có lỗi xảy ra.');
    } finally {
      setLoading(false);
    }
  }, [username, currentUser]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  const handleFollowToggle = async () => {
    if (!userProfile || !currentUser) return;
    try {
      if (isFollowing) {
        await api.delete(`/users/${userProfile._id}/follow`);
        setUserProfile(prev =>
          prev
            ? {
                ...prev,
                followers: prev.followers.filter(id => id !== currentUser._id),
              }
            : prev
        );
      } else {
        await api.post(`/users/${userProfile._id}/follow`);
        setUserProfile(prev =>
          prev
            ? { ...prev, followers: [...prev.followers, currentUser._id] }
            : prev
        );
      }
      setIsFollowing(f => !f);
    } catch (err) {
      console.error('Lỗi khi thực hiện theo dõi/bỏ theo dõi:', err);
    }
  };

  if (loading) return <div className="page-status">Đang tải hồ sơ...</div>;
  if (error) return <div className="page-status error">{error}</div>;
  if (!userProfile) return null;

  return (
    <div className="profile-page">
      <ProfileHeader
        userProfile={userProfile}
        isFollowing={isFollowing}
        onFollowToggle={handleFollowToggle}
      />
      <div className="profile-content">
        <UserPostList userId={userProfile._id} />
      </div>
    </div>
  );
};

export default ProfilePage;
