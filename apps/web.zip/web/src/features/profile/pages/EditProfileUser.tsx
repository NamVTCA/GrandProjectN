import { useState, useEffect, type ChangeEvent, type FormEvent } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../../../services/api'; // ← sử dụng chung instance API
import type { UserProfile } from '../types/UserProfile';
import styles from './EditProfileUser.module.scss';
import { useAuth } from '../../auth/AuthContext';

const EditProfileUser: React.FC = () => {
  const { username } = useParams<{ username: string }>();
  const navigate = useNavigate();
  const { user, setUser } = useAuth();

  const [profile, setProfile] = useState<Partial<UserProfile>>({});
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [coverFile, setCoverFile] = useState<File | null>(null);

  // Fetch profile data
  useEffect(() => {
    if (!username) return;
    api.get<UserProfile>(`/users/${username}`)
      .then(res => setProfile(res.data))
      .catch(() => alert('Không tải được hồ sơ.'));
  }, [username]);

  // Handle text/textarea change
  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };

  // Handle avatar file & preview
  const handleAvatarChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setAvatarFile(file);
    if (file) {
      setProfile(prev => ({ ...prev, avatar: URL.createObjectURL(file) }));
    }
  };

  // Handle cover file & preview
  const handleCoverChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setCoverFile(file);
    if (file) {
      setProfile(prev => ({ ...prev, coverImage: URL.createObjectURL(file) }));
    }
  };

  // Helper to build public URL for server-stored images
  const publicUrl = (path: string) =>
    path.startsWith('http') ? path : `http://localhost:8888${path}`;

  // Merge dữ liệu trả về từ API vào user context
  const mergeToAuthUser = (data: Partial<UserProfile>) => {
    if (user) {
      setUser({ ...user, ...data });
    }
  };

  // Submit form
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      // 1) Cập nhật name & bio
      const textRes = await api.patch<UserProfile>('/users/me', {
        name: profile.name,
        bio: profile.bio,
      });
      mergeToAuthUser(textRes.data);

      // 2) Upload avatar nếu có
      if (avatarFile) {
        const fd = new FormData();
        fd.append('avatar', avatarFile);
        const avatarRes = await api.patch<UserProfile>('/users/me/avatar', fd, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        mergeToAuthUser(avatarRes.data);
      }

      // 3) Upload cover nếu có
      if (coverFile) {
        const fd = new FormData();
        fd.append('cover', coverFile);
        const coverRes = await api.patch<UserProfile>('/users/me/cover', fd, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        mergeToAuthUser(coverRes.data);
      }

      // 4) Redirect
      navigate(`/profile/${username}`);
    } catch (err: any) {
      console.error('Profile update error', err.response || err);
      alert(`Cập nhật thất bại: ${err.response?.data?.message || err.message}`);
    }
  };

  return (
    <div className={styles.container}>
      <h1>Chỉnh sửa hồ sơ</h1>
      <form onSubmit={handleSubmit} className={styles.form}>
        {/* Cover upload */}
        <label>
          Ảnh bìa
          <input type="file" accept="image/*" onChange={handleCoverChange} />
        </label>
        {profile.coverImage && (
          <img
            src={
              profile.coverImage.startsWith('blob:')
                ? profile.coverImage
                : publicUrl(profile.coverImage)
            }
            alt="Cover preview"
            className={styles.previewCover}
          />
        )}

        {/* Avatar upload */}
        <label>
          Avatar
          <input type="file" accept="image/*" onChange={handleAvatarChange} />
        </label>
        {profile.avatar && (
          <img
            src={
              profile.avatar.startsWith('blob:')
                ? profile.avatar
                : publicUrl(profile.avatar)
            }
            alt="Avatar preview"
            className={styles.previewAvatar}
          />
        )}

        {/* Display name */}
        <label>
          Tên hiển thị
          <input
            type="text"
            name="name"
            value={profile.name || ''}
            onChange={handleChange}
          />
        </label>

        {/* Bio */}
        <label>
          Tiểu sử
          <textarea
            name="bio"
            rows={4}
            value={profile.bio || ''}
            onChange={handleChange}
          />
        </label>

        {/* Buttons */}
        <div className={styles.buttons}>
          <button type="submit" className={styles.save}>
            Lưu
          </button>
          <button type="button" className={styles.cancel} onClick={() => navigate(-1)}>
            Hủy
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditProfileUser;
